namespace MultiSafepay.Model
{
    public class SimpleResult
    {
        public bool Success { get; set; }
    }
}