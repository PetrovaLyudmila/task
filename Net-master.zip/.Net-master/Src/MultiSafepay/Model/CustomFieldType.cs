﻿namespace MultiSafepay.Model
{
    public enum CustomFieldType
    {
        textbox, 
        selectbox, 
        checkbox, 
        radiolist
    }
}