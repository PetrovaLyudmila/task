﻿namespace MultiSafepay.Model
{
    public enum RoundingMode
    {
        UP, 
        DOWN, 
        CEILING, 
        HALF_UP, 
        HALF_DOWN, 
        HALF_EVEN
    }
}