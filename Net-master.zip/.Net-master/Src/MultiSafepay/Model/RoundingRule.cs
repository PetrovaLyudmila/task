﻿namespace MultiSafepay.Model
{
    public enum RoundingRule
    {
        PER_ITEM, 
        PER_LINE, 
        TOTAL
    }
}