﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MultiSafepay.Model
{
    public class TokenResponse
    {
        public TokenData[] Tokens { get; set; }
    }
}
