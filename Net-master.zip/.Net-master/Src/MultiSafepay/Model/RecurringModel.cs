﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MultiSafepay.Model
{
    public enum RecurringModelType
    {
        cardOnFile,
        subscription,
        unscheduled
    }
}
