﻿namespace MultiSafepay.Model
{
    public enum StandardCustomField
    {
        vatnumber, 
        companyname, 
        chamberofcommerce, 
        driverslicense, 
        passportnumber, 
        birthday, 
        sex, 
        newsletter, 
        comment, 
        mobilephonenumber, 
        salutation, 
        phonenumber, 
        acceptagreements
    }
}