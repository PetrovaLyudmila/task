﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiSafepay.IntegrationTests
{
    public class Settings
    {
        public static string MultiSafePayUrl = "https://testapi.multisafepay.com/v1/json/";
        public static string ApiKey = "YOUR_TEST_API_KEY";
    }
}
