﻿namespace Samples
{
    public class CreatePayAfterDeliverOrder
    {
    }
}
